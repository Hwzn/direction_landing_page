
- File types  html + css + js.
- Folder structure:
  - assets/images for dynamic images (dummy data images) .
  - assets/css Style File.
  - assets/fonts All Fonts .
  - assets/js script File.

---
- Used BootStrap.
- Used Owl Carousel.
- Used Font Awesome.
---
## Live

[Preview Live](https://housemadecom.com/)


## Preview Images From Site

# Home Page

![Home Page](assets/images/screen_one.png)
